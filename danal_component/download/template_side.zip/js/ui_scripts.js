 

$(document).ready(function() {
	/* 팝업닫기*/
	$('.pop_close').on('click',function(e){
		e.preventDefault();
        $('.ly_item_tools').css('display','none');
    });
    

	
	/* 사이드메뉴 숨기기*/
	var cont = 0;
	$('.aside_btn').on('click', function() {
		if (cont == 0) {
			$('.aside > .menu_w').animate({
				left : -240
			}, 200);
			$('.aside').animate({
				width : 0
			}, 200);
			$('.container').animate({
				'margin-left' : '0'
			}, 200);
			$('.btn_function').animate({
				left : 0
			}, 200);
			$('.side_close').addClass('on');
			cont = 1;
		} else {
			$('.aside > .menu_w').animate({left :0},0);
			$('.aside').animate({width :240}, 0);
			$('.container').css({'margin-left' : '240px'});
			$('.aside_btn').removeClass('on');
			cont = 0;
		};
		if(datatable) {
			setTimeout(function () {
				datatable.columns.adjust().draw();
			}, 500);
		}
	});

	$(window).resize(function () {
		/*$(".cont_wrap_fix.list_view").css("top", $(".cont_wrap_fix").eq(0).outerHeight(true) - 20);
		if (datatable) {
			datatable.columns.adjust().draw();
		}*/
	});
	
	/*검색 디테일*/
	$('.detailed_fild').hide();
	$('.detailed').on('click', function() {
		$('.detailed_fild').slideToggle(0);
		$(this).toggleClass("open");
	});
	/*그래프 열기*/
	$('.graph_st01').show();
	$('.graph_close').on('click', function() {
		$('.graph_st01').slideToggle(300);
	});
	/*메뉴 열기*/
	$('.service_m').on('click', function() {
        $('.ly_dimmed').show();
        $('.service_m_fild').show();
	});
	$('.pop_close').on('click', function() {
        $('.ly_dimmed').hide();
        $('.ly_menu').hide();
	});

	/*레이어팝업 open*/
	var type;
	/*레이어팝업 height 위치 중앙 정렬*/
	// var lHPosition = function() {
	// 	var lHeight = $('.lh_p').height();
	// 	var winWidth = $(window).width();
	// 	var winHeight = $(window).height();
	// 	var hPosition = (winHeight - lHeight) / 2;
    //
	// 	$(".lh_p").css("top", hPosition);
	// };
	// $(window).resize(function() {
	// 	lHPosition();
	// });
	// lHPosition();

});

$(document).ready(function() {
	/*notice/faq*/
	$('.acoordion_b').hide();
	$('.acoordion_h').on('click', function() {
		$(this).parent().find('.acoordion_b').slideToggle(100);
		$(this).find('a').toggleClass('active');
	});

	$('.ico_info').on('click', function () {
		$('.m_info').toggle();
	});
});