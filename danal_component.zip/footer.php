            <!-- footer-->
            <div class="footer">
                <div class="footer_contents">
                    <span class="bottom_logo"></span>
                    <span>13591 경기도 성남시 분당구 분당로 55 퍼스트타워 9층<br>
                        <b>대표자</b> 박상만 <b>Tel</b> 031-697-1004 <b>Fax</b> 031-697-1461 <b>사업자등록번호</b> 113-81-44055 <b>통신판매신고번호</b> 경기성남 2007-541<br>
                        COPYRIGHT <b>DANAL</b> Co., LTD. ALL RIGHTS RESERVED</span>
                </div>
            </div>
            <!-- footer-->
        </div>
        <!-- wrap-->
        <script>
        	$("#header li").each(function () {
        		if ($(this).data("title") == "<?=$page_title?>") {
        			$(this).addClass("active");
        		}
        	});
        </script>
    </body>
</html>
